# Titanic ML Project

## Описание
Классический ML проект на данных Titanic. Цель — предсказать выживаемость пассажиров.

## Структура проекта
- `src/` — исходный код (модули)
- `notebooks/eda.ipynb` — исследовательский анализ данных
- `submissions/` — сгенерированные файлы для Kaggle
- `outputs/` — результаты (JSON с метриками)

## Установка
```bash
pip install -r requirements.txt