"""
Главный скрипт проекта Titanic ML
Запуск: python main.py
"""

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression

sys.path.insert(0, str(Path(__file__).parent))

from src.config import get_config
from src.data_loader import load_train_data, load_test_data
from src.preprocessor import preprocess_data
from src.feature_engineering import build_features
from src.evaluate import cross_validate_models, grid_search_models, compare_k_folds
from src.ensemble import create_ensembles
from src.dnn_model import train_dnn, predict_dnn
from src.train import get_model
from src.utils import setup_logger, save_results, save_submission_from_preds

warnings.filterwarnings("ignore")


def ensure_numeric(df):
    for col in df.select_dtypes(include=['object', 'category']).columns:
        df[col] = df[col].astype('category').cat.codes
    return df


def main():
    config = get_config()
    logger = setup_logger()
    logger.info("=" * 60)
    logger.info("Запуск Titanic ML пайплайна")
    logger.info("=" * 60)

    # Загрузка данных
    logger.info("Загрузка данных...")
    train_df = load_train_data(config.train_path)
    test_df = load_test_data(config.test_path)
    logger.info(f"Train: {train_df.shape}, Test: {test_df.shape}")

    # Предобработка
    logger.info("Предобработка данных...")
    train_processed = preprocess_data(train_df, config, fit=True)
    test_processed = preprocess_data(test_df, config, fit=False)
    logger.info("Предобработка завершена")

    # Создание признаков
    logger.info("Создание новых признаков...")
    X, y = build_features(train_processed, config)
    X_test = build_features(test_processed, config, fit=False)[0]
    X = ensure_numeric(X)
    X_test = ensure_numeric(X_test)
    logger.info(f"Создано признаков: {X.shape[1]}")

    # ---- Выделяем валидационную выборку для оценки ансамблей ----
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=config.random_state, stratify=y
    )
    logger.info(f"Train size: {X_train.shape[0]}, Val size: {X_val.shape[0]}")

    # ---- Обучаем базовые модели на X_train ----
    logger.info("Обучение базовых моделей на train...")
    model_names = ["random_forest", "catboost", "xgboost", "lightgbm", "logistic_regression"]
    trained_models_val = {}
    for name in model_names:
        model = get_model(name, config)
        if model is not None:
            model.fit(X_train, y_train)
            trained_models_val[name] = model

    # ---- DNN на X_train ----
    logger.info("Обучение DNN на train...")
    dnn_model_val = train_dnn(X_train, y_train, config=config)
    dnn_preds_val = predict_dnn(dnn_model_val, X_val)

    # ---- Получаем предсказания базовых моделей на X_val ----
    val_preds_dict = {}
    for name, model in trained_models_val.items():
        if hasattr(model, "predict_proba"):
            val_preds_dict[name] = model.predict_proba(X_val)[:, 1]
        else:
            val_preds_dict[name] = model.predict(X_val).astype(float)
    val_preds_dict['dnn'] = dnn_preds_val

    # ---- Оцениваем ансамбли на X_val ----
    logger.info("Оценка ансамблей на валидации...")
    ensemble_scores = {}

    # 1. Simple average
    simple_avg = np.mean(list(val_preds_dict.values()), axis=0)
    ensemble_scores['simple_average'] = np.mean((simple_avg >= 0.5) == y_val)

    # 2. Weighted average (равные веса)
    weights = np.ones(len(val_preds_dict))
    weights = weights / weights.sum()
    weighted_avg = np.sum(np.column_stack(list(val_preds_dict.values())) * weights, axis=1)
    ensemble_scores['weighted_average'] = np.mean((weighted_avg >= 0.5) == y_val)

    # 3. Hard voting
    binary_preds = np.column_stack([(p >= 0.5).astype(int) for p in val_preds_dict.values()])
    hard_vote = np.apply_along_axis(lambda x: np.bincount(x).argmax(), axis=1, arr=binary_preds)
    ensemble_scores['hard_voting'] = np.mean(hard_vote == y_val)

    # 4. Stacking (обучаем стек на X_train, предсказываем на X_val)
    logger.info("Оценка стекинга на валидации...")
    estimators = [(name, model) for name, model in trained_models_val.items() if name != 'dnn']
    stack = StackingClassifier(
        estimators=estimators,
        final_estimator=LogisticRegression(C=1.0, random_state=config.random_state),
        cv=5,
        n_jobs=-1
    )
    stack.fit(X_train, y_train)
    stack_preds_val = stack.predict_proba(X_val)[:, 1]
    ensemble_scores['stacking'] = np.mean((stack_preds_val >= 0.5) == y_val)

    # ---- Вывод и сохранение метрик ансамблей ----
    logger.info("Результаты на валидации:")
    for name, score in ensemble_scores.items():
        logger.info(f"  {name}: {score:.4f}")

    # ---- Теперь обучаем все модели на полных данных X, y ----
    logger.info("Обучение финальных моделей на всех данных...")
    cv_results = cross_validate_models(X, y, config)
    trained_models = cv_results["trained_models"]

    # ---- GridSearch ----
    logger.info("GridSearch для Random Forest и CatBoost...")
    grid_results = grid_search_models(X, y, config)

    # ---- DNN на всех данных ----
    logger.info("Обучение DNN на всех данных...")
    dnn_model = train_dnn(X, y, config=config)
    dnn_preds = predict_dnn(dnn_model, X_test)

    # ---- СОХРАНЕНИЕ САБМИТОВ ДЛЯ ВСЕХ МОДЕЛЕЙ ----
    logger.info("Сохранение сабмитов для всех моделей...")
    
    for name, model in trained_models.items():
        try:
            if hasattr(model, "predict_proba"):
                preds = model.predict_proba(X_test)[:, 1]
            else:
                preds = model.predict(X_test).astype(float)
            save_submission_from_preds(preds, test_df['PassengerId'], suffix=f"model_{name}")
            logger.info(f"  Сохранён: submissions/submission_model_{name}.csv")
        except Exception as e:
            logger.warning(f"  Не удалось сохранить {name}: {e}")
    
    if dnn_preds is not None:
        save_submission_from_preds(dnn_preds, test_df['PassengerId'], suffix="model_dnn")
        logger.info("  Сохранён: submissions/submission_model_dnn.csv")
    
    best_name = cv_results['best_name']
    best_model = trained_models.get(best_name)
    if best_model:
        if hasattr(best_model, "predict_proba"):
            best_preds = best_model.predict_proba(X_test)[:, 1]
        else:
            best_preds = best_model.predict(X_test).astype(float)
        save_submission_from_preds(best_preds, test_df['PassengerId'], suffix="best_model")
        logger.info("  Сохранён: submissions/submission_best_model.csv")

    # ---- Сравнение 1 vs 5 фолдов ----
    logger.info("Сравнение 1 vs 5 фолдов...")
    compare_df = compare_k_folds(X, y, config)

    # ---- Ансамбли для финального сабмита ----
    logger.info("Создание ансамблей для сабмита...")
    ensemble_results = create_ensembles(
        X, y, X_test, trained_models, cv_results, config,
        extra_preds={'dnn': dnn_preds}
    )

    # ---- Стек для сабмита ----
    logger.info("Создание стекинга для сабмита...")
    top_models = {k: trained_models[k] for k in ['random_forest', 'catboost', 'xgboost'] if k in trained_models}
    estimators = [(name, model) for name, model in top_models.items()]
    stack_final = StackingClassifier(
        estimators=estimators,
        final_estimator=LogisticRegression(C=1.0, random_state=config.random_state),
        cv=5,
        n_jobs=-1
    )
    stack_final.fit(X, y)
    stacking_preds = stack_final.predict_proba(X_test)[:, 1]
    ensemble_results['stacking'] = {'test_pred': stacking_preds, 'description': 'Stacking (LR)'}

    # ---- Сохранение сабмитов для ВСЕХ АНСАМБЛЕЙ ----
    logger.info("Сохранение сабмитов для всех ансамблей...")
    for name, result in ensemble_results.items():
        if name in ['best_name', 'best_pred', 'best_model']:
            continue
        if 'test_pred' in result:
            preds = result['test_pred']
            save_submission_from_preds(preds, test_df['PassengerId'], suffix=name)
            logger.info(f"  Сохранён: submissions/submission_{name}.csv")

    # ---- Сохранение результатов ----
    save_results(cv_results, ensemble_results, config, grid_results=grid_results, fold_comparison=compare_df,
                 ensemble_scores=ensemble_scores)
    logger.info("Результаты сохранены в outputs/results.json")

    # ---- Финальный сабмит (лучший ансамбль по валидации) ----
    best_val_ensemble = max(ensemble_scores, key=ensemble_scores.get)
    logger.info(f"Лучший ансамбль по валидации: {best_val_ensemble} ({ensemble_scores[best_val_ensemble]:.4f})")
    
    best_preds = ensemble_results[best_val_ensemble]['test_pred']
    save_submission_from_preds(best_preds, test_df['PassengerId'], suffix="best_ensemble")
    logger.info(f"  Сохранён: submissions/submission_best_ensemble.csv")

    logger.info("=" * 60)
    logger.info(f"Готово. Лучшая модель CV: {cv_results['best_name']} ({cv_results['best_score']:.4f})")
    logger.info(f"Лучший ансамбль по валидации: {best_val_ensemble} ({ensemble_scores[best_val_ensemble]:.4f})")
    logger.info("=" * 60)


if __name__ == "__main__":
    main()