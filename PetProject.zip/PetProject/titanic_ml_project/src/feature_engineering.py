"""
Создание новых признаков
"""

import pandas as pd
import numpy as np


def build_features(df: pd.DataFrame, config, fit: bool = True):
    """
    Создание признаков для модели
    
    Returns:
        X: признаки (DataFrame)
        y: целевая переменная (Series или None)
    """
    data = df.copy()
    
    # Age_band
    bins = [0, 16, 32, 48, 64, 100]
    labels = [0, 1, 2, 3, 4]
    data["Age_band"] = pd.cut(data["Age"], bins=bins, labels=labels, right=False)
    data["Age_band"] = data["Age_band"].astype(float)
    
    # Family_Size
    data["Family_Size"] = data.get("SibSp", 0) + data.get("Parch", 0)
    
    # Alone
    data["Alone"] = (data["Family_Size"] == 0).astype(int)
    
    # Fare_cat
    if "Fare" in data.columns:
        data["Fare_cat"] = pd.qcut(
            data["Fare"].clip(lower=0.01),
            q=config.fare_bins,
            labels=False,
            duplicates="drop"
        ).astype(float)
    
    # Удаление ненужных колонок
    drop_cols = ["Name", "Ticket", "Cabin", "PassengerId"]
    for col in drop_cols:
        if col in data.columns:
            data = data.drop(columns=[col])
    
    # Разделение на X и y
    if "Survived" in data.columns:
        y = data["Survived"]
        X = data.drop(columns=["Survived"])
        return X, y
    else:
        X = data
        return X, None  # всегда возвращаем кортеж