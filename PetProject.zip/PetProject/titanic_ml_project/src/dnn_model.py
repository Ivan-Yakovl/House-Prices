"""
Модель глубокой нейронной сети (PyTorch)
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np


class MLP(nn.Module):
    """Многослойный перцептрон с BatchNorm и Dropout"""
    
    def __init__(self, input_dim, hidden_sizes, output_dim=1, activation='relu', dropout_rate=0.3, use_batchnorm=True):
        super().__init__()
        
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_sizes:
            layers.append(nn.Linear(prev_dim, h_dim))
            if use_batchnorm:
                layers.append(nn.BatchNorm1d(h_dim))
            if activation == 'relu':
                layers.append(nn.ReLU(inplace=True))
            elif activation == 'tanh':
                layers.append(nn.Tanh())
            else:
                layers.append(nn.ReLU(inplace=True))
            layers.append(nn.Dropout(dropout_rate))
            prev_dim = h_dim
        
        layers.append(nn.Linear(prev_dim, output_dim))
        layers.append(nn.Sigmoid())  # для бинарной классификации
        
        self.net = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.net(x)


def train_dnn(X_train, y_train, X_val=None, y_val=None, config=None):
    """Обучение DNN"""
    
    if config is None:
        hidden_sizes = [128, 64, 32]
        batch_size = 64
        learning_rate = 0.001
        n_epochs = 100
        dropout_rate = 0.3
        use_batchnorm = True
        activation = 'relu'
    else:
        hidden_sizes = config.dnn_hidden_sizes
        batch_size = config.dnn_batch_size
        learning_rate = config.dnn_learning_rate
        n_epochs = config.dnn_n_epochs
        dropout_rate = config.dnn_dropout_rate
        use_batchnorm = config.dnn_batch_norm
        activation = config.dnn_activation
    
    # Преобразование DataFrame в numpy, если необходимо
    if hasattr(X_train, 'values'):
        X_train = X_train.values
    if hasattr(y_train, 'values'):
        y_train = y_train.values
    
    # Приводим к float32
    X_t = torch.FloatTensor(X_train)
    y_t = torch.FloatTensor(y_train).reshape(-1, 1)
    
    dataset = TensorDataset(X_t, y_t)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    
    model = MLP(
        input_dim=X_train.shape[1],
        hidden_sizes=hidden_sizes,
        output_dim=1,
        activation=activation,
        dropout_rate=dropout_rate,
        use_batchnorm=use_batchnorm
    )
    
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.BCELoss()
    
    model.train()
    for epoch in range(n_epochs):
        epoch_loss = 0.0
        for batch_X, batch_y in loader:
            optimizer.zero_grad()
            preds = model(batch_X)
            loss = criterion(preds, batch_y)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
        if (epoch+1) % 20 == 0:
            print(f"  DNN epoch {epoch+1}/{n_epochs}, loss: {epoch_loss/len(loader):.4f}")
    
    model.eval()
    return model


def predict_dnn(model, X):
    """Предсказание вероятностей"""
    model.eval()
    # Преобразование DataFrame в numpy
    if hasattr(X, 'values'):
        X = X.values
    with torch.no_grad():
        X_t = torch.FloatTensor(X)
        probs = model(X_t).numpy().flatten()
    return probs