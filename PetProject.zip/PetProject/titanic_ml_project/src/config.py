"""
Конфигурация проекта
Все гиперпараметры и настройки вынесены в этот файл
"""


class Config:
    def __init__(self):
        # Данные
        self.train_path = "data/train.csv"
        self.test_path = "data/test.csv"
        self.random_state = 42

        # Предобработка
        self.fill_age = True
        self.fill_embarked = True
        self.normalize = False
        self.age_bins = 5
        self.fare_bins = 4

        # Кросс-валидация
        self.n_folds = 5
        self.stratified = True
        self.shuffle = True
        self.scoring = "accuracy"
        self.n_jobs = -1

        # Logistic Regression
        self.lr_C = 1.0
        self.lr_max_iter = 1000
        self.lr_solver = "liblinear"

        # Ridge
        self.ridge_alpha = 1.0

        # Lasso
        self.lasso_C = 1.0

        # ElasticNet
        self.en_C = 1.0
        self.en_l1_ratio = 0.5

        # KNN
        self.knn_n_neighbors = 5
        self.knn_weights = "uniform"
        self.knn_metric = "minkowski"

        # Decision Tree
        self.dt_max_depth = 5
        self.dt_min_samples_split = 5

        # Random Forest
        self.rf_n_estimators = 100
        self.rf_max_depth = 10
        self.rf_min_samples_split = 5
        self.rf_min_samples_leaf = 2

        # CatBoost
        self.cb_iterations = 500
        self.cb_learning_rate = 0.1
        self.cb_depth = 6
        self.cb_verbose = False
        self.cb_early_stopping_rounds = 50

        # XGBoost
        self.xgb_n_estimators = 500
        self.xgb_learning_rate = 0.1
        self.xgb_max_depth = 6
        self.xgb_subsample = 0.8
        self.xgb_colsample_bytree = 0.8

        # LightGBM
        self.lgb_n_estimators = 500
        self.lgb_learning_rate = 0.1
        self.lgb_num_leaves = 31
        self.lgb_max_depth = -1

        # DNN (PyTorch)
        self.dnn_hidden_sizes = [128, 64, 32]   # размеры скрытых слоёв
        self.dnn_activation = 'relu'            # 'relu' или 'tanh'
        self.dnn_dropout_rate = 0.3
        self.dnn_batch_norm = True
        self.dnn_learning_rate = 0.001
        self.dnn_batch_size = 64
        self.dnn_n_epochs = 100
        self.dnn_optimizer = 'adam'             # 'adam' или 'sgd'

        # Ансамбли
        self.ensemble_methods = ["simple", "weighted"]


def get_config():
    return Config()